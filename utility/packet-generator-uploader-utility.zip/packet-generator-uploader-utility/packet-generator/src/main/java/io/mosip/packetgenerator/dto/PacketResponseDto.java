package io.mosip.packetgenerator.dto;

import lombok.Data;

@Data
public class PacketResponseDto {
	private String registartionId;
	private String status;

}
