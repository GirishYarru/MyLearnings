package io.mosip.packetgenerator.constant;

public enum GenderType {
	MALE, FEMALE;
	//OTHER
}
